// enforce only digits for CPF and limit to 11
$(document).on('input', 'input[name="CPF"]', function() {
  this.value = this.value.replace(/\D/g, '').slice(0,11);
});

// Bootstrap + HTML5 validation
(function () {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
