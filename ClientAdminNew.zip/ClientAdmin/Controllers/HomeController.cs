using Microsoft.AspNetCore.Mvc;

namespace ClientAdmin.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Error() => View();
    }
}
